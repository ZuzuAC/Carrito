<?php
session_start();

if (isset($_GET['action'])) {
    $id = intval($_GET['id']);

    switch ($_GET['action']) {
        case 'add':
            if (!isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id] = 1;
            } else {
                $_SESSION['cart'][$id]++;
            }
            break;
        case 'remove':
            if (isset($_SESSION['cart'][$id])) {
                unset($_SESSION['cart'][$id]);
            }
            break;
        case 'update':
            if (isset($_POST['quantity']) && is_array($_POST['quantity'])) {
                foreach ($_POST['quantity'] as $productId => $quantity) {
                    $productId = intval($productId);
                    $quantity = intval($quantity);
                    if (isset($_SESSION['cart'][$productId]) && $quantity > 0) {
                        $_SESSION['cart'][$productId] = $quantity;
                    }
                }
            }
            break;
    }
}

header('Location: cart.php');
exit;
