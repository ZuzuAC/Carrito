<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notas de Alumnos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 14px;
        }
        input[type="submit"],
        input[type="reset"] {
            width: 20%;
            padding: 8px 12px;
            margin: 5px 0;
            box-sizing: border-box;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h1>Registro de Notas de Alumnos</h1>
    <form action="ej1.php" method="post">
        <label for="nombre">Nombre del Alumno:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="teorico">Nota Teórico (20%):</label>
        <input type="number" id="teorico" name="teorico" min="0" max="10" step="0.01" required>

        <label for="practico">Nota Práctico (20%):</label>
        <input type="number" id="practico" name="practico" min="0" max="10" step="0.01" required>

        <label for="trabajo">Nota Trabajo (20%):</label>
        <input type="number" id="trabajo" name="trabajo" min="0" max="10" step="0.01" required>

        <label for="proyecto">Nota Proyecto (40%):</label>
        <input type="number" id="proyecto" name="proyecto" min="0" max="10" step="0.01" required>

        <input type="submit" value="Calcular Promedio">
    </form>
</body>
</html>



<?php
 // Inicializamos la sesión

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $teorico = $_POST["teorico"];
    $practico = $_POST["practico"];
    $trabajo = $_POST["trabajo"];
    $proyecto = $_POST["proyecto"];


    $alumno_actual = [
        "nombre" => $nombre,
        "teorico" => $teorico,
        "practico" => $practico,
        "trabajo" => $trabajo,
        "proyecto" => $proyecto,
    ];


    if (!isset($_SESSION["alumnos"])) {
        $_SESSION["alumnos"] = []; 
    }
    $_SESSION["alumnos"][] = $alumno_actual;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Notas de Alumnos</title>
    <style>

    </style>
</head>
</html>

<?php
session_start(); // Inicializamos la sesión

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $teorico = $_POST["teorico"];
    $practico = $_POST["practico"];
    $trabajo = $_POST["trabajo"];
    $proyecto = $_POST["proyecto"];


    $promedio = ($teorico * 0.2 + $practico * 0.2 + $trabajo * 0.2 + $proyecto * 0.4);


    $estado = ($promedio >= 7) ? "Aprobado" : "Reprobado";

    
    $imagen_aprobado = "pulgara.jpg"; 
    $imagen_reprobado = "pulgaraa.png"; 
    $alumno_actual = [
        "nombre" => $nombre,
        "teorico" => $teorico,
        "practico" => $practico,
        "trabajo" => $trabajo,
        "proyecto" => $proyecto,
        "promedio" => $promedio,
        "estado" => $estado,
        "imagen" => ($estado === "Aprobado") ? $imagen_aprobado : $imagen_reprobado // Determinamos qué imagen mostrar
    ];

    // Agregamos el arreglo del alumno actual al arreglo general de alumnos
    if (!isset($_SESSION["alumnos"])) {
        $_SESSION["alumnos"] = []; // Inicializamos el arreglo si aún no existe
    }
    $_SESSION["alumnos"][] = $alumno_actual;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Notas de Alumnos</title>
    <style>
        /* Estilos CSS para la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f5f5f5;
        }
        .estado-img {
            width: 30px;
            height: 30px;
        }
    </style>
</head>
<body>
    <h1>Resultados de Notas de Alumnos</h1>
    <?php

if (isset($_SESSION["alumnos"])) {
    echo "<table border='1'>";
    echo "<tr><th>Nombre</th><th>Teórico</th><th>Práctico</th><th>Trabajo</th><th>Proyecto</th></tr>";
    foreach ($_SESSION["alumnos"] as $alumno) {
        echo "<tr>";
        echo "<td>{$alumno['nombre']}</td>";
        echo "<td>{$alumno['teorico']}</td>";
        echo "<td>{$alumno['practico']}</td>";
        echo "<td>{$alumno['trabajo']}</td>";
        echo "<td>{$alumno['proyecto']}</td>";
        echo "</tr>";
    }
    echo "</table>";
}




    if (isset($_SESSION["alumnos"])) {
        echo "<table border='1'>";
        echo "<tr><th>Nombre</th><th>Promedio</th><th>Estado</th></tr>";
        foreach ($_SESSION["alumnos"] as $alumno) {
            echo "<tr>";
            echo "<td>{$alumno['nombre']}</td>";
            echo "<td>{$alumno['promedio']}</td>";
            echo "<td>{$alumno['estado']} <img src='{$alumno['imagen']}' alt='{$alumno['estado']}' class='estado-img'></td>";
            echo "</tr>";
        }
        echo "</table>";




        // Calcular el promedio del grupo
        $total_alumnos = count($_SESSION["alumnos"]);
        $promedio_grupo = array_sum(array_column($_SESSION["alumnos"], "promedio")) / $total_alumnos;

        // Calcular el porcentaje de aprobados y reprobados
        $aprobados = array_filter($_SESSION["alumnos"], function($alumno) {
            return $alumno['estado'] === 'Aprobado';
        });
        $total_aprobados = count($aprobados);
        $total_reprobados = $total_alumnos - $total_aprobados;
        $porcentaje_aprobados = ($total_aprobados / $total_alumnos) * 100;
        $porcentaje_reprobados = ($total_reprobados / $total_alumnos) * 100;

        echo "<p>Promedio del grupo: $promedio_grupo</p>";
        echo "<p>Porcentaje de aprobados: $porcentaje_aprobados%</p>";
        echo "<p>Porcentaje de reprobados: $porcentaje_reprobados%</p>";
    } else {
        echo "No se han ingresado datos de alumnos.";
    }
    ?>
</body>
</html>


