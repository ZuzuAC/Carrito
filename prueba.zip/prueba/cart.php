<?php
session_start();

$products = isset($_SESSION['products']) ? $_SESSION['products'] : [];
$totalPrice = 0; // Nueva variable para almacenar el total

function getProductById($id, $products)
{
    foreach ($products as $product) {
        if ($product['id'] == $id) {
            return $product;
        }
    }
    return false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 2px solid #007bff; /* Bordes azules mamalones */
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .product-image {
            width: 100px; /* Ancho fijo para las imágenes */
            height: auto; /* Altura automática para mantener la proporción */
        }
        button {
            background-color: #007bff; /* Botón azul */
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Carrito de Compras</h2>
    <?php if (!empty($_SESSION['cart'])): ?>
        <form action="action_cart.php?action=update" method="post">
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Total</th>
                        <th>Imagen</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $id => $quantity): ?>
                        <?php $product = getProductById($id, $products); ?>
                        <?php
                            $itemTotal = $product['price'] * $quantity;
                            $totalPrice += $itemTotal; // Suma al total
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td>$<?= htmlspecialchars($product['price']) ?></td>
                            <td>
                                <input type="number" name="quantity[<?= $id ?>]" value="<?= $quantity ?>" min="1">
                            </td>
                            <td>$<?= $itemTotal ?></td>
                            <td><img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image"></td>
                            <td><a href="action_cart.php?action=remove&id=<?= $id ?>">Eliminar</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Total:</strong></td>
                        <td>$<?= $totalPrice ?></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
            <button type="submit">Actualizar Carrito</button>
        </form>
    <?php else: ?>
        <p>Tu carrito está vacío.</p>
    <?php endif; ?>

    <a href="index1.php">Continuar Comprando</a>
</body>
</html>

