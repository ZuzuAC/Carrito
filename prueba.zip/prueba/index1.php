<?php
session_start();

if (!isset($_SESSION['products'])) {
    $_SESSION['products'] = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $image = filter_input(INPUT_POST, 'image', FILTER_SANITIZE_URL);

    if ($name && $price && $image) {
        $_SESSION['products'][] = ['id' => count($_SESSION['products']) + 1, 'name' => $name, 'price' => $price, 'image' => $image];
    } else {
        echo "<p>Error al añadir el producto. Asegúrese de que todos los campos son correctos.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form, .product, .cart { margin-bottom: 20px; }
        .product, .cart-item { border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; display: flex; align-items: center; }
        .product img, .cart-item img { width: 100px; height: 100px; margin-right: 20px; }
        ul { list-style: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { text-decoration: none; color: blue; }
    </style>
</head>
<body>
    <h2>Agregar Producto</h2>
    <form action="index1.php" method="post">
        <input type="text" name="name" placeholder="Nombre del producto" required>
        <input type="text" name="price" placeholder="Precio" required>
        <input type="text" name="image" placeholder="URL de la imagen" required>
        <button type="submit" name="add_product">Agregar Producto</button>
    </form>

    <h2>Productos</h2>
    <ul>
        <?php foreach ($_SESSION['products'] as $product): ?>
            <li class="product">
                <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                <div>
                    <strong><?= htmlspecialchars($product['name']) ?></strong> - $<?= htmlspecialchars($product['price']) ?>
                    - <a href="action_cart.php?action=add&id=<?= $product['id'] ?>">Agregar al Carrito</a>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>

    <a href="cart.php">Ver Carrito</a>
</body>
</html>



<a href="logout.php">Cerrar Sesión</a>